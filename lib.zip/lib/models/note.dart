import 'package:flutter/cupertino.dart';

class Note {
  final String title;
  final String description;
  final DateTime time;

  Note(this.title, this.description, this.time);
}
