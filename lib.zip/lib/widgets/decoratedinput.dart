import 'package:flutter/material.dart';

class Cinput extends StatelessWidget {
  final TextEditingController controller;
  final String lable;
  final int? maxlines;

  const Cinput(
      {Key? key, required this.controller, required this.lable, this.maxlines})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      maxLines: maxlines,
      decoration: InputDecoration(
          border: const OutlineInputBorder(
              borderSide: BorderSide(
            width: 4,
            color: Colors.blue,
          )),
          label: Text(lable)),
    );
  }
}
