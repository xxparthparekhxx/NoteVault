import 'package:flutter/material.dart';
import 'package:notes/models/note.dart';
import 'package:notes/screens/notesDescription.dart';

class NoteTile extends StatelessWidget {
  final Function delete;
  final int index;
  const NoteTile({
    Key? key,
    required this.N,
    required this.delete,
    required this.index,
  }) : super(key: key);

  final Note N;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(width: 1),
          borderRadius: const BorderRadius.all(Radius.circular(10))),
      child: Material(
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          onTap: () {
            print("This is pressed");
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => NotesDescription(N: N)));
          },
          child: Container(
              width: 300,
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            flex: 2,
                            child: Text(
                              N.title,
                              maxLines: 1,
                              softWrap: true,
                              style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  overflow: TextOverflow.ellipsis),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: IconButton(
                                iconSize: 25,
                                onPressed: () {
                                  delete(index);
                                },
                                icon: Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                )),
                          )
                        ],
                      ),
                      Text(
                        N.description,
                        maxLines: 9,
                        softWrap: true,
                        style: const TextStyle(
                            fontSize: 14, overflow: TextOverflow.ellipsis),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(N.time.toString().split(".")[0].split(" ")[1]),
                        ],
                      ),
                    ],
                  )
                ],
              )),
        ),
      ),
    );
  }
}
