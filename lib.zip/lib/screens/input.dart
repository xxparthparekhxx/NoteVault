import 'package:flutter/material.dart';
import 'package:notes/widgets/decoratedinput.dart';

class input extends StatefulWidget {
  final Function update;
  const input({Key? key, required this.update}) : super(key: key);

  @override
  State<input> createState() => _inputState();
}

class _inputState extends State<input> {
  TextEditingController title = TextEditingController();
  TextEditingController description = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Cinput(controller: title, lable: "Enter a Title", maxlines: 1),
          SizedBox(
            height: 20,
          ),
          Cinput(
            controller: description,
            lable: "Description",
            maxlines: 4,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                    onPressed: () => {
                          widget.update(title.text, description.text),
                          Navigator.pop(context)
                        },
                    child: Text("Save"))
              ],
            ),
          )
        ],
      ),
    );
  }
}
