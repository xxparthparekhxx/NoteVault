import 'package:flutter/material.dart';
import 'package:notes/models/note.dart';
import 'package:notes/screens/input.dart';
import 'package:notes/screens/notesDescription.dart';
import 'package:notes/widgets/note_tile.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<Note> Notes = [
    Note("Test", "Test", DateTime.now()),
    Note("Testtitle", "Testdescription", DateTime.now()),
    Note("Testtitle", "Testdescription", DateTime.now()),
  ];

  void deleteNoteat(int index) {
    Notes.removeAt(index);
    setState(() {});
  }

  void addNote(String title, String description) {
    Notes.add(Note(title, description, DateTime.now()));
    print('Note added dsuccesfully');
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      appBar: AppBar(
        title: const Text("Notes App"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.builder(
            itemCount: Notes.length,
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 300,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20),
            itemBuilder: (c, index) => NoteTile(
                  N: Notes[index],
                  delete: deleteNoteat,
                  index: index,
                )),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add, color: Colors.black),
        onPressed: () => showModalBottomSheet(
            context: context, builder: (c) => input(update: addNote)),
      ),
    );
  }
}
